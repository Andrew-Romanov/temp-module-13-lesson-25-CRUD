// import './js/r - get';
// import './js/c - post';
// import './js/u - patch';
// import './js/d - delete';
